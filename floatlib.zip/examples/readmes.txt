Asm(prgmE2Pi) simply displays e^pi which the OS says is 23.14069263. Compare to 23.1407.
Asm(prgmATANAGM) takes a string as input, converts it to a float, then uses the AGM-like algorithm to compute the arctangent of that number.
    For example:
        "-.776":Asm(prgmATANAGM returns -0.65993, compare to -.6599345219. 

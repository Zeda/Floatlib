Floatlib
Zeda Thomas

Devices
    This app works on the TI-83+, TI-84+, TI-83+SE, TI-84+SE, TI-84+pocket.fr

What is this?
    I authored the Z80 Single Precision Floating Point Library, and this app makes use of it.
  It takes all of those routines and puts it into an app that can be referenced by user programs.
  Along with these routines, I added in a reference of sorts to facilitate on-the-calc
  programming which is especially useful for those frequently away from a computer.


Loading code: (A hexadecimal version can be found in-app and it is slightly different.)
---------------------------------------------------------------------------------------
    #include "header.z80"
    ;Your code goes here
---------------------------------------------------------------------------------------


import math
hexstr="0123456789abcdef"
def tohex(x,n=2):
    x=int(x)
    s=""
    for i in range(n):
        s=hexstr[x%16]+s
        x=int(x/16)
    return s
def single_ext(x):
    if x==0:
        return ".db $00,$00,$00,$00,$00"
    s=0
    if x<0:
        s=1
        x=-x
    e=128
    while x>=2:
        x*=.5
        e+=1
    while x<1:
        x*=2
        e-=1
    if x<=0:
        if s==0:
            return ".db $00,$00,$00,$00,$00"
        else:
            return ".db $00,$00,$00,$80,$00"
    if x>255:
        if s==0:
            return ".db $00,$00,$00,$40,$00"
        else:
            return ".db $00,$00,$00,$C0,$00"
    x=float(int(x*2**32+1)*2**-32)
    if x>=2:
        x*=.5
        e+=1
    x+=s-1
    x*=128
    s=",$"+tohex(e)
    s=",$"+tohex(x)+s
    x-=int(x)
    x*=256
    s=",$"+tohex(x)+s
    x-=int(x)
    x*=256
    s=",$"+tohex(x)+s
    x-=int(x)
    x*=256
    return ".db $"+tohex(x)+s
def complex_table(i,s):
    s+=single_ext(2**i*math.log(1-2**-i))+"\n"
    s+=single_ext(2**i*math.log(1+2**-i))+"\n"
    s+=single_ext(2**(i-1)*math.log(1+2*2**-i+2*4**-i))+"\n"
    s+=single_ext(2**(i-1)*math.log(1-2*2**-i+2*4**-i))+"\n"
    s+=single_ext(2**(i-1)*math.log(1+4**-i))+"\n"
    s+=single_ext(2**i*math.atan(1.0/(2**i+1)))+"\n"
    s+=single_ext(2**i*math.atan(1.0/(2**i-1)))+"\n"
    return s+single_ext(2**i*math.atan(2**-i))+"\n"

s=""
for i in range(1,11):
#    s+=complex_table(i,s)
    s+=single_ext(1.0/((12-i)*(11-i)))+"\n"
f=open("table.txt","w+")
f.write(s)
f.close()

